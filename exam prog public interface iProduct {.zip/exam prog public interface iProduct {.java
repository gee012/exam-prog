public interface iProduct {

    int getTotalProductSales(int[][] sales);
    double getAverageProductSales(int[][] sales);
    String getMostPopularProduct(int[][] sales);
}
*1.2
public class Product implements Iproducts {

 @Override
    public int getTotalProductSales(int[][]sales) {
        int total = 0 ;
         for (int i = 0; i < sales.length; i++){
             for(int j = 0; j < sales[i].length; j++) {
                 total =+ sales [i][j];
             }
         }
        return totai;
    }
    
   @Override
    public double  getAverageProductSales(int[][] sales) {
        int total = getTotalProductSales(sales);
        int count = sales.length * sales[0].length; 
        return (double) total / count;
    }

   @Override
    public  String getMostPopularproduct(int[][] sales, String[] products) {
        int max = sales[0][0];
        String popular = products[0];
        for (int i = 0; i <sales.length; i++) {
            for (int j = 0; j< sales[i].length;j++){
                if (sales[i][j] > max){
                    max = sales[i][j];
                    popular = products[i];
                }
            }
        }
        return popular = " (" + max + ")";
                }
            }
        }
    }

}
Q2..
public interface IProductcalculations {

    double GwtVat();
    double GetCommisiion();
    double GetTotal();
